import java.lang.Math.*

fun main() {
    try {
        println("Введите x, M, K и N ")
        print("x = ")
        val x = readLine()!!.toDouble()
        print("M = ")
        val M = readLine()!!.toInt()
        print("K = ")
        val K = readLine()!!.toInt()
        print("N = ")
        val N = readLine()!!.toInt()
        val y: Double
        when (M){
            max(K, N)  -> y = sin(abs(x)) / pow(x, 2.0)
            min(K, N)  -> y = sin(abs(x)) / (pow(x, 2.0) + 1)
            else -> y = -1.0
        }
        println("y = " + y)
    }
    catch (e: Exception) {
        println("Введены не коректные данные")
    }
}