import java.lang.Math.pow
import kotlin.math.sqrt

fun main() {
    try {
        println("Введите a, b и c ")
        print("a = ")
        val a = readLine()!!.toDouble()
        print("b = ")
        val b = readLine()!!.toDouble()
        print("c = ")
        val c = readLine()!!.toDouble()
        val D : Double = pow(b, 2.0) - (4 * a * c)
        val x : Double
        when{
            D > 0 -> {
                val x1 : Double = ((-b) - sqrt(D)) / (2.0 * a)
                val x2 : Double = ((-b) + sqrt(D)) / (2.0 * a)
                println("x1 = " + x1 + "\nx2 = " + x2)
            }
            D == 0.0 -> {
                x = -b / (2.0 * a)
                println("Всего один корень: " + x)
            }
            else -> println("Корней нет")
        }
    }
    catch (e: Exception) {
        println("Введены не коректные данные")
    }
}