import kotlin.math.sqrt

fun main(){
    try {
        print("Введите h: ")
        val h = readLine()!!.toDouble()
        if (h > 0) {
           val t = sqrt(2.0 * h / 9.8)
           println("Время падения равно: " + t)
        }
        else
            println("Введена не коректная высота")

    }
    catch (e:Exception)
    { println("Введен символ")}
}