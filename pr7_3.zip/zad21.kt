import java.lang.Math.pow
import kotlin.math.sqrt

fun main(){
    try {
        println("Введите диагональ и большее основнаие прямоугольника: ")
        print("d = ")
        val d = readLine()!!.toDouble()
        print("b = ")
        val b = readLine()!!.toDouble()
        if (d > 0 && b > 0){
            val a = sqrt(pow(d, 2.0) - pow(b, 2.0))
            val s = a * b
            println("Меньшее основание равно: " + a + "\nПлощадь равна: " + s)
        }
        else
            println("Введены не коректные данные")
    }
    catch (e:Exception)
    { println("Введен символ")}
}