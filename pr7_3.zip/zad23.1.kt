

fun main() {
    try {
        println("Введите точки ")
        print("x1 = ")
        val x1 = readLine()!!.toDouble()
        print("y1 = ")
        val y1 = readLine()!!.toDouble()
        print("x2 = ")
        val x2 = readLine()!!.toDouble()
        print("y2 = ")
        val y2 = readLine()!!.toDouble()
        print("x3 = ")
        val x3 = readLine()!!.toDouble()
        print("y3 = ")
        val y3 = readLine()!!.toDouble()
        print("x4 = ")
        val x4 = readLine()!!.toDouble()
        print("y4 = ")
        val y4 = readLine()!!.toDouble()
        when((x1 * y1)  >= -1.5 && (x1 * y1) <= 1.5) {
            true -> println("1 точка принадлежит графику a")
            false -> println("1 точка не принадлежит графику а")
        }
        when((x2 * y2)  >= -2 && (x2 * y2) <= 2){
            true -> println("2 точка принадлежит графику б")
            false -> println("2 точка не принадлежит графику б")
        }
        when((x3 * y3)  >= -2 && (x3 * y3) <= 1) {
            true -> println("3 точка принадлежит графику в")
            false -> println("3 точка не принадлежит графику в")
        }
        when((x4 * y4)  >= -1 && (x4 * y4) <= 2) {
            true -> println("4 точка принадлежит графику г")
            false -> println("4 точка не принадлежит графику г")
        }
    }
    catch (e: Exception) {
        println("Введены не коректные данные")
    }
}